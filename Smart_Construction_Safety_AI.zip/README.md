# Smart Construction Safety AI
*Final project for the Building AI course*  
*Building AI course project*

## Summary
Smart Construction Safety AI is a computer vision–based tool that detects unsafe situations on construction sites in real time, such as missing helmets, unsafe zones, or fall risks. It aims to reduce accidents and protect workers through early detection and instant alerts.

## Background
Construction sites are among the most hazardous workplaces. Thousands of injuries happen every year due to:

* Missing personal protective equipment (PPE)  
* Workers entering restricted or dangerous zones  
* Poor visibility or unsafe behavior  
* Heavy machinery accidents  
* Fall hazards  

As someone with a civil engineering background and now studying information systems, I want to use modern AI tools to improve construction-site safety. This is important because even small improvements can save lives, reduce injuries, and support safer workplaces.

## How is it used?
The AI system connects to cameras installed on the construction site. It continuously scans video frames and identifies:

* Workers without helmets or safety vests  
* People entering hazardous zones  
* Unsafe distances from machinery  
* Slipping or falling risks  
* Unusual worker behavior  

When the AI detects a risk, it alerts:

* Site supervisors (via dashboard/app)  
* Workers (via mobile notification or wearable device)  
* Safety officers (via automated report)

This tool can be used on small or large construction sites, roadwork areas, and industrial projects.

Example image format (replace with your uploaded image later):
![Example](https://tinyurl.com/elementsofaicat)

## Data sources and AI methods
### Data sources
The project uses:

* Construction-site images or videos  
* Public PPE datasets (helmet/no helmet)  
* Custom images collected from sample environments  
* Optional sensor data (temperature, noise, humidity)

### AI techniques
* Computer Vision – YOLOv8 or OpenCV to detect objects (helmet, worker, zones)  
* Risk classification – Decision Trees or Random Forest  
* Time-based prediction – LSTM for hazard forecasting  
* Image labeling – to train the model on PPE and unsafe behavior  

Example code snippet:
```
from ultralytics import YOLO
model = YOLO("yolov8n.pt")
results = model("site_image.jpg")
results.show()
```

## Challenges
* Poor lighting or bad camera quality may reduce accuracy  
* The system may require many training images  
* Privacy concerns: Worker consent and ethical monitoring  
* AI cannot replace human judgment  
* Hardware (cameras & sensors) can be costly  
* False alarms might occur in complex environments  

## What next?
This project can grow by adding:

* Drone-based monitoring for large sites  
* Integration with BIM and Digital Twin models  
* Voice alerts for workers  
* A mobile app dashboard  
* More specific hazard prediction models  

To scale this project, I would need:  
* Real construction-site data  
* Expertise from safety officers  
* Collaboration with machine learning engineers  

## Acknowledgments
* Inspired by challenges in construction safety  
* YOLOv8 by Ultralytics (open-source)  
* Building AI course guidance by Reaktor & University of Helsinki  
* Example image credit: “Sleeping Cat on Her Back by Umberto Salvagnin” / CC BY 2.0  
* Markdown template provided by the Building AI course team  
